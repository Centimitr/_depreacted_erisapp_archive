import { Erisapp.ComPage } from './app.po';

describe('erisapp.com App', () => {
  let page: Erisapp.ComPage;

  beforeEach(() => {
    page = new Erisapp.ComPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
