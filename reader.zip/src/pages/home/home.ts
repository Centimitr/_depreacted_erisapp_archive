import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit {

  imgs: object[] = [];

  constructor() {

  }

  async  ngOnInit() {
    const res = await window.fetch('http://localhost:3455/book?locator=/Users/shixiao/Desktop/maid.rar');
    const bm = await res.json();
    if (bm && bm.Pages) {
      const pages = bm.Pages;
      const urls = pages.map(pm => pm.Locator).map(l => 'http://localhost:3455/book/page?locator=/Users/shixiao/Desktop/maid.rar&page=' + l);
      this.imgs = urls.map(u => ({src: u}));
    }
  }

}
