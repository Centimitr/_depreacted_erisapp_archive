export interface Size {
  w: number;
  h: number;
}
