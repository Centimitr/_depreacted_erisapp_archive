class Mutex {
  Lock(){}
  Unlock(){}
}
export const sync = {
  Mutex
};
